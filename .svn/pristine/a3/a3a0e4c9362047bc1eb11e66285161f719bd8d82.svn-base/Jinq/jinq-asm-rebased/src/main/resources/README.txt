There is no source code or JavaDoc for this module since it is simply a 
rebased version of the jars from the ASM bytecode framework that allows
Jinq to use its own private copy of ASM without worrying about dependency
conflicts with other libraries that also use ASM.