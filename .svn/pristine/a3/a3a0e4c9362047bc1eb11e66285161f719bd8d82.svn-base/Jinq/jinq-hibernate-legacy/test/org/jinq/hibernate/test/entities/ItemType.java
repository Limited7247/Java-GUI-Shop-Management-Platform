package org.jinq.hibernate.test.entities;

public enum ItemType 
{
   SMALL, BIG, OTHER
}
