package org.jinq.jpa.jpqlquery;

public interface JPQLFragment
{

}
